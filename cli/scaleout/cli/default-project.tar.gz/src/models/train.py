#------------------- Required for tracking ---------------------#
import sys
from tracking.trackingclient import TrackingClient, save_metadata
run_id = sys.argv[1]
tracker = TrackingClient()
#---------------------------------------------------------------#
