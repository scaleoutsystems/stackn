#------------------- Required for tracking ---------------------#
from tracking.trackingclient import TrackingClient
tracker = TrackingClient()
#---------------------------------------------------------------#

