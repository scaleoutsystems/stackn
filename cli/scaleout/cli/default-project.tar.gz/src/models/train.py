#------------------- Required for tracking ---------------------#
from scaleout.trackingclient import TrackingClient
tracker = TrackingClient()
#---------------------------------------------------------------#

