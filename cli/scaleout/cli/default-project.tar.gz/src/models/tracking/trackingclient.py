import sys
import pickle

class TrackingClient():
    def __init__(self):
        print("Creating tracking client for current training session.")
        self.id = sys.argv[1]
        self.params = {}
        self.metrics = {}
        self.model = {}
    
    def log_params(self, params):
        self.params = {
            **self.params, 
            **params
        }
        
    def log_metrics(self, metrics):
        self.metrics = {
            **self.metrics, 
            **metrics
        }

    def log_model(self, model_type, model):
        self.model = {
            **self.model, 
            **{'type': model_type, 'fitted_model': model}
        }

    def save_tracking(self):
        f = 'src/models/tracking/metadata/{}.pkl'.format(self.id) 
        print("Tracking completed. Saving tracked metadata in src/models/tracking/metadata as {}.".format(f))
        metadata = {}
        for attr, value in self.__dict__.items():
            if value:
                metadata[attr] = value
            else:
                print("No {} logged during training of the model.".format(attr))
        try:
            with open(file_to_save, 'wb') as metadata_file:
                pickle.dump(metadata, metadata_file, pickle.HIGHEST_PROTOCOL)
                print("Values for the following metadata was tracked during training and will be saved in Studio: {}".format(list(metadata.keys()).remove('run_id')))
        except Exception as e: # Should catch more specific error here
            print("Error")    
        
