class TrackingClient():
    def __init__(self):
        print("Creating tracker client for current training session.")
        self.params = {}
        self.metrics = {}
        self.model = {}

    def log_params(self, params):
        self.params = {
            **self.params, 
            **params
        }
        
    def log_metrics(self, metrics):
        self.metrics = {
            **self.metrics, 
            **metrics
        }

    def log_model(self, model_type, model):
        self.model = {
            **self.model, 
            **{'type': model_type, 'fitted_model': model}
        }

def save_metadata(tracker, run_id):
    #recorded_data = [a for a in dir(tracker) if not a.startswith('__') and not callable(getattr(tracker, a))]
    metadata = {}
    metadata['params'] = tracker.params
    metadata['metrics'] = tracker.metrics
    metadata['model'] = tracker.model
    import pickle
    with open('src/models/tracking/metadata/{}.pkl'.format(run_id), 'wb') as metadata_file:
        pickle.dump(metadata, metadata_file, pickle.HIGHEST_PROTOCOL)
    

    


#def fetch_tracker():
#    with open('tracking/runs/tracker.pkl', 'rb') as input:
#        print("fetching tracker")
#        tracker = pickle.load(input)
#        print(tracker.params)



"""
        self.params = {
            'params': {}
        }
        self.metrics = {
            'metrics': {}
        }
        self.model = {
            'model': {}
        }
        """

"""
    def log_params(self, params):
        self.params['params'] = {
            **self.params['params'], 
            **params
        }
        

    def log_metrics(self, metrics):
        self.metrics['metrics'] = {
            **self.metrics['metrics'], 
            **metrics
        }


    def log_model(self, model_type, model):
        self.model['model'] = {
            **self.model['model'], 
            **{'type': model_type, 'fitted_model': model}
        }
    """


"""
    def log_params(self, params):
        #self.params['params'] = {**self.params['params'], **params}
        model_params = self.params['params']
        for key, value in params.items():
            model_params[key] = value
        self.params['params'] = model_params


    def log_metrics(self, metrics):
        #self.metrics['metrics'] = {**self.metrics['metrics'], **metrics}
        model_metrics = self.metrics['metrics']
        for key, metric in metrics.items():
            #self.metrics[key] = value
            model_metrics[key] = value
        self.metrics['metrics'] = model_metrics
"""